This is a secure chatroom created by Halle Gumpel, Hannah Main, Kieran Human usng Python 3.9

It uses the following Python libraries:
	* select
	* socket
	* sys
	* threading
	* time
	* OpenSSL
Running `./setup.sh` will pip install these dependencies
