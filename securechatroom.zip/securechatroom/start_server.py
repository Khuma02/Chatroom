#!/usr/bin/env python3

import socket
import select
import sys
import os
from threading import *

HEADER_LEN = 10

#establish server
server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
#allow reconnection
server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

def check_valid_host(HOST):
    valid = False
    if HOST.count(".") == 3:
        checkformat = True
    nums = HOST.split('.')
    if HOST[0].isnumeric and HOST[1].isnumeric and HOST[2].isnumeric:
        checknums = True
    if checkformat == True and checknums == True:
        valid = True
    if valid == True:
        return True
    else:
        print("Not a valid IPv4 address")
        return False

#see if IP or Port address were given
if len(sys.argv) != 3:
    print("IP Address and/or Port Number not given, using default IP and Port: 127.0.0.1:1234")
    IP = '127.0.0.1'
    PORT = 1234

#check if inputed ip and port address are valid
else:
    IP = str(sys.argv[1])
    check_valid_host(IP)
    PORT = int(sys.argv[2])
    if len(str(PORT)) != 4:
        print("Not a valid Port address")
        exit()
#set server socket to inputed ip and port address
server_socket.bind((IP, PORT))
print(f"...setting up server socket on address {IP}:{PORT}")

#allow server to listen for new traffic
server_socket.listen()
sockets = [server_socket]
clients = {} 
print("...Listening for connections...")

class colors:
    NAME= '\033[92m'
    ENDC = '\033[0m'

def receive_msg(client):
    #receives info and checks its a valid header
    try:
        header = client.recv(HEADER_LEN)

        if not len(header):
            return False

        msg_len = int(header.decode("utf-8").strip())
        return {"header": header, "data": client.recv(msg_len)}

    except:
        return False

while True:
    read_sockets, _, exception_sockets = select.select(sockets, [], sockets)

    for current_soc in read_sockets:
        #create new user in server
        if current_soc == server_socket:
            client, address = server_socket.accept()
            user = receive_msg(client)
            if user is False:
                continue
            sockets.append(client)
            clients[client] = user
            print(f"Welcome {user['data'].decode('utf-8')}")
        #message received, print message
        else:
            msg = receive_msg(current_soc)
            if msg is False:
                print(f"{clients[current_soc]['data'].decode('utf-8')} left the chat")
            
            user = clients[current_soc]
            #verify cert exists
            cert_path = f"{user['data']}_signed.crt"
            cert_path = cert_path[2:]
            cert_path = cert_path.replace("'","")
            if os.path.isfile(cert_path): 
                #broadcast to all clients except sender
                for client_soc  in clients:
                    if client_soc != current_soc:
                        client_soc.send(user['header']+user['data'] + msg['header'] + msg['data'])
            #printing data sent to server
                print(f"{colors.NAME}{user['data'].decode('utf-8')}{colors.ENDC}> {msg['data'].decode('utf-8')}")
            else:
                msg = "Error: Could not send message"
                msg = msg.encode('utf-8')
                msgHeader = f"{len(msg):<{HEADER_LEN}}".encode('utf-8')
                for client_soc in clients:
                    if client_soc == current_soc:
                        client_soc.send(msgHeader + msg)
