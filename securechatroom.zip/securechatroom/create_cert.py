#!/usr/bin/env python3

from OpenSSL import crypto, SSL

def create_cert():
    #create user
    print("Create your account:")
    email_address = input("   Email address: ")
    common_name = input("   Your name: ")
    country_name = input("   Country: ")
    locality_name = country_name
    state_name = input("   State or Province: ")
    org_name = input("   Organization Name: ")
    org_unit_name = org_name

    KEY_FILE = "private.key"
    CERT_FILE = f"{common_name}_signed.crt"

    #create public key
    k = crypto.PKey()
    #create private key with RSA encryption
    k.generate_key(crypto.TYPE_RSA, 4096)

    #create cert
    cert = crypto.X509()
    cert.get_subject().C = country_name
    cert.get_subject().ST = state_name
    cert.get_subject().L = locality_name
    cert.get_subject().O = org_name
    cert.get_subject().OU = org_unit_name
    cert.get_subject().CN = common_name
    cert.get_subject().emailAddress = email_address
    cert.set_serial_number(0)

    cert.gmtime_adj_notBefore(0)
    cert.gmtime_adj_notAfter(10*365*24*60*60)
    cert.set_issuer(cert.get_subject())
    cert.set_pubkey(k)
    cert.sign(k, 'sha512')
    try:
        with open(CERT_FILE, "wt") as file:
            file.write(crypto.dump_certificate(crypto.FILETYPE_PEM, cert).decode("utf-8"))
        return True
    except IOError as e:
        print(e)
        return False
    
    try:
        with open(KEY_FILE, "wt") as file:
            file.write(crypto.dump_privatekey(crypto.FILETYPE_PEM, k).decode("utf-8"))
        return True
    except IOError as e:
        print(e)
        return False
