#!/usr/bin/env python3

import select
import socket
import sys
import time
from threading import Thread
import create_cert

class colors:
    NAME= '\033[92m'
    ENDC = '\033[0m'

thread_running = True

#Global vars
HEAD_LEN = 10
IP = "127.0.0.1"
PORT = 1234

if len(sys.argv) != 3:
    print("IP Address and/or Port Number not given, using default IP and Port: 127.0.0.1:1234")
    IP = '127.0.0.1'
    PORT = 1234

answer = input("Welcome to SecureChat. Do you want to continue the setup of your account?(yes/no)")
while answer != "yes":
    if answer == "no":
        print("...Exiting out of program...")
        exit()
    else:
        answer = input("Not a valid answer. You must input either 'yes' or 'no'. Do you want to continue setting up your account?")

myName = input("What do you want your display name to be?: ")

try:
    create_cert.create_cert()
    print("Account Created. Start Messaging Other people")
except:
    print("Could not create certificate...Exiting...")
    exit()

#Create the socket and connec to the IP/Port
clientSocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
clientSocket.connect((IP, PORT))

#Put the connection to not be blocking
clientSocket.setblocking(False)

#Do the name and header, then send
name = myName.encode('utf-8')
nameHeader = f"{len(name):<{HEAD_LEN}}".encode('utf-8')
clientSocket.send(nameHeader + name)


#Thread for receiving messages
def getMessageFromOther():
    global thread_running

    start_time = time.time()

    # run this while there is no input
    while thread_running:
        time.sleep(0.1)
        try:
            while True:

                #Receieve the header
                nameHeader = clientSocket.recv(HEAD_LEN)

                if not len(nameHeader):
                    print('The connection was closed by the server')
                    sys.exit()

                #Decode header
                nameLen = int(nameHeader.decode('utf-8').strip())
                #Get and decode name
                name = clientSocket.recv(nameLen).decode('utf-8')
                #do above on the actual message
                msgHeader = clientSocket.recv(HEAD_LEN)
                msgLen = int(msgHeader.decode('utf-8').strip())
                msg = clientSocket.recv(msgLen).decode('utf-8')

                print(f'{colors.NAME}{name}:{colors.ENDC} {msg}')
        #if theres no message, then we move on
        except IOError as e:
            continue

#Thread for sending messages
def getUserInput():
    while True:

        #Wait for the user to input a message
        msg = input()

        if msg:

            #Encode the message
            msg = msg.encode('utf-8')
            msgHeader = f"{len(msg):<{HEAD_LEN}}".encode('utf-8')
            clientSocket.send(msgHeader + msg)

#Start the two threads
if __name__ == '__main__':
    t1 = Thread(target = getMessageFromOther)
    t2 = Thread(target = getUserInput)

    t1.start()
    t2.start()

    t2.join()
    thread_running = False


