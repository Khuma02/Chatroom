#!/bin/bash

#install dependencies

pip3 install sockets pyOpenSSL

